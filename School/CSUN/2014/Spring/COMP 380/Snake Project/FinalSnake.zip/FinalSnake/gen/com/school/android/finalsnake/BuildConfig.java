/** Automatically generated file. DO NOT MODIFY */
package com.school.android.finalsnake;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}