//----------------------------------------------------------------------
// ArrayListStack.java        by Dale/Joyce/Weems              Chapter 3
//
// Implements UnboundedStackInterface using an object.ArrayList to 
// hold the stack elements.
//----------------------------------------------------------------------

package ArrayListStack;

import java.util.*;

public class ArrayListStack<T> implements UnboundedStackInterface<T>
{
	protected ArrayList<T>	stack;	// object.ArrayList that holds stack elements
	public int elementCount = 0;
	
	public ArrayListStack()
	{
		stack = new ArrayList<T>();
	}

	public void push(T element)		// Places element at the top of this stack.
	{
		stack.add(element);
		elementCount++;
	}

	public void pop()				// Throws StackUnderflowException if this stack is empty,...
	{								// ...otherwise removes top element from this stack.
		if (!isEmpty())
		{
			stack.remove(stack.size() - 1);
			elementCount--;
		} 
		else
			throw new StackUnderflowException("Pop attempted on an empty stack.");
	}

	public T top()					// Throws StackUnderflowException if this stack is empty,
	{								// otherwise returns top element from this stack.
		T topOfStack = null;
		if (!isEmpty())
			topOfStack = stack.get(stack.size() - 1);
		else
			throw new StackUnderflowException("Top attempted on an empty stack.");
		return topOfStack;
	}

	public T popInto(ArrayListStack<T> receiver)	//	Pops from a stack into another stack while returning a backup
	{
		T top = top();
		receiver.push(top());
		pop();
		return top;
	}
	
	public void incorporate(ArrayListStack<T> source)	//	Includes a source stack into the calling stack
	{
		int numToCopy = source.elementCount;
		for (int i = 0; i < numToCopy; i++)
		{
			push(source.top());
			source.pop();
		}
	}
	
	public void incorporateArray(T[] arrayToCopy, int count)	//	Includes an array into the calling stack
	{
		for (int i = 0; i < count; i++)
			push(arrayToCopy[i]);
	}
	
	public boolean isEmpty()	// Returns true if this stack is empty, otherwise returns false.
	{
		if (stack.size() == 0)
			return true;
		else
			return false;
	}
	
	public int getCount()
	{
		return elementCount;
	}
	
	public void EmptyStack()	//	Empty the stack
	{
		int count = elementCount;
		for (int i = 0; i < count; i++)
			pop();
	}
	
	public void reversed()		//	Reverses the calling stack
	{
		ArrayListStack<T> reversed = new ArrayListStack<T>();
		int count = elementCount;
		
		for (int i = 0; i < count; i++)
		{
			popInto(reversed);
		}
		addStack(reversed);
	}
	
	public void addStack (ArrayListStack<T> stackToCopy)		//	Adds one stack onto another
	{
		ArrayListStack<T> receiver = new ArrayListStack<T>();
		ArrayListStack<T> temp = new ArrayListStack<T>();
		
		int elementCount = stackToCopy.elementCount;
		
		for (int i = 0; i < elementCount; i++)
		{
			temp.push(stackToCopy.popInto(receiver));
		}
		stackToCopy.incorporate(receiver);
		incorporate(temp);
	}
}