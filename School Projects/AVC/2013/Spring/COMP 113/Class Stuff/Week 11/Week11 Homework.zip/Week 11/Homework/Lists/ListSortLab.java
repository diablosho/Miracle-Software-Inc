package Lists;

/**
 * @(#)ListSortLab.java
 * 
 * 
 * @author Follow the instructions in the main section of the code
 */

public class ListSortLab
{

	/**
	 * Creates a new instance of <code>ListSort</code>.
	 */
	public ListSortLab()
	{
	}

	public static void main(String[] args)
	{
		RefSortedList<Integer> list = new RefSortedList<Integer>();

		// print the list size

		// add the following integers to the list 11, 1, 5, 2

		// print the list size

		// print out the entire list

		// check if the list contains 2 and output the results

		// check if the list contains 3 and output the results

		// output the results of using the get method using 11 as the argument

		// output the results of using the get method using 3 as the argument

		// reset the list

		// using a loop issue the getNext method 6 times and print the results
		// for each getNext

		// remove 99 and 5 from the list

		// print out the entire list

	}
}