/*	//////////////////////////////////////////////////////////////////////////////////////////////////////////
 *	Name:  		Brian Jones
 *	Class:		CIS 113
 *	Date:		4/25/2013
 *	Assignment:	Chapter 6 Homework/Labs
 *		Fix Sorts.java to track number of swaps and comparisons in sorting algorithms, and to display the data
 *		correctly and efficiently. 
 *	//////////////////////////////////////////////////////////////////////////////////////////////////////////
 */
/*	//////////////////////////////////////////////////////////////////////////////////////////////////////////
 * 	Sorts.java               by Dale/Joyce/Weems modified by Lee     Chapter 10
 * 	Test harness used to run sorting algorithms.
 * 	This is preparation for a final project if you choose not to take the final exam.
 *	//////////////////////////////////////////////////////////////////////////////////////////////////////////
 */
package Sorts;
import java.util.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.DecimalFormat;

public class Sorts	//	Declare cntSwaps and cntComparisons to track swaps and comparisons in sorting algorithms
{
	static final int	SIZE			=	100000;					// size of array to be sorted
	static int[]		values			= 	new int[SIZE];			// values to be sorted
	static final int	randSize		= 	100000;
	static int			sortIdentifier 	= 	0;
	static int			cntSwaps[]		= 	{	0, 0, 0, 0	};
	static int			cntComparisons[]= 	{	0, 0, 0, 0	};
	static long 		startTime[]		= 	{	0, 0, 0, 0	},
						stopTime[] 		= 	{	0, 0, 0, 0	};

	static void initRndValues()			//	Initialize the values array with random integers from 0 to randSize
	{
		Random rand = new Random();
		cntSwaps[0] = 0;
		cntSwaps[1] = 0;
		cntSwaps[2] = 0;
		cntSwaps[3] = 0;
		cntComparisons[0] = 0;
		cntComparisons[1] = 0;
		cntComparisons[2] = 0;
		cntComparisons[3] = 0;
		
		for (int index = 0; index < SIZE; index++)
			values[index] = rand.nextInt(randSize);
	}
	static void initDescValues()	//	Initialize cntSwaps and cntComparisons to 0, and initialize array values with
	{								//	Descending #s, from SIZE to 1
		cntSwaps[0] = 0;
		cntSwaps[1] = 0;
		cntSwaps[2] = 0;
		cntSwaps[3] = 0;
		cntComparisons[0] = 0;
		cntComparisons[1] = 0;
		cntComparisons[2] = 0;
		cntComparisons[3] = 0;
		
		for (int index = SIZE; index > 0; index--)
			values[SIZE-index] = index;
	}
	static void initAscValues()		//	Initialize cntSwaps and cntComparisons to 0, and initialize array values with
	{								//	Ascending #s, from 1 to SIZE
		cntSwaps[0] = 0;
		cntSwaps[1] = 0;
		cntSwaps[2] = 0;
		cntSwaps[3] = 0;
		cntComparisons[0] = 0;
		cntComparisons[1] = 0;
		cntComparisons[2] = 0;
		cntComparisons[3] = 0;
		
		for (int index = 0; index < SIZE; index++)
			values[index] = index;
	}
	static public boolean isSorted()			// Returns true if the array values are sorted and false otherwise.
	{
		boolean sorted = true;
		for (int index = 0; index < (SIZE - 1); index++)
		{
			cntComparisons[sortIdentifier]++;
			if (values[index] > values[index + 1])
				sorted = false;
		}
		return sorted;
	}
	static public void swap(int index1, int index2)		// Swaps the integers at locations index1 and index2 
	{													//	of the values array.
		// Precondition: index1 and index2 are >= 0 and < SIZE.
		int temp = values[index1];
		values[index1] = values[index2];
		values[index2] = temp;
		cntSwaps[sortIdentifier]++;
	}
	static void selectionSort()							//	Returns the index of the smallest value in 
	{													//	values[startIndex]..values[endIndex].
		startTime[sortIdentifier] = startClock();
		int endIndex = SIZE - 1;
		
		for (int current = 0; current < endIndex; current++)
			swap(current, minIndex(current, endIndex));
		
		stopTime[sortIdentifier] = stopClock();
	}
	static int minIndex(int startIndex, int endIndex)
	{
		int indexOfMin = startIndex;
		for (int index = startIndex + 1; index <= endIndex; index++)
		{
			cntComparisons[sortIdentifier]++;
			if (values[index] < values[indexOfMin])
				indexOfMin = index;
		}
		return indexOfMin;
	}	
	static void bubbleSort()							// Switches adjacent pairs that are out of order between 
	{										//	values[startIndex]..values[endIndex], beginning at values[endIndex].
		startTime[sortIdentifier] = startClock();

		for (int current = 0; current < (SIZE - 1); current++)
			bubbleUp(current, SIZE - 1);
		
		stopTime[sortIdentifier] = stopClock();
	}
	static void bubbleUp(int startIndex, int endIndex)
	{
		for (int index = endIndex; index > startIndex; index--)
		{
			cntComparisons[sortIdentifier]++;
			if (values[index] < values[index - 1])
				swap(index, index - 1);
		}
	}
	static void shortBubble()							// Switches adjacent pairs that are out of order between 
	{										//	values[startIndex]..values[endIndex], beginning at values[endIndex].
		startTime[sortIdentifier] = startClock();
		boolean sorted = false;
		
		for (int current = 0; (current < (SIZE - 1) && !sorted); current++)
			sorted = bubbleUp2(current, SIZE - 1);
		
		stopTime[sortIdentifier] = stopClock();
	}
	static boolean bubbleUp2(int startIndex, int endIndex)	// Sorts the values array using the bubble sort algorithm.
	{														//  The process stops as soon as values is sorted.
		boolean sorted = true;
		for (int index = endIndex; index > startIndex; index--)
		{
			cntComparisons[sortIdentifier]++;
			if (values[index] < values[index - 1])
			{
				swap(index, index - 1);
				sorted = false;
			}
		}
		return sorted;
	}	
	static void insertionSort()							// Sorts the values array using the insertion sort algorithm.
	{
		startTime[sortIdentifier] = startClock();
		for (int count = 1; count < SIZE; count++)
			insertItem(0, count);

		stopTime[sortIdentifier] = stopClock();
	}
	static void insertItem(int startIndex, int endIndex)	// Upon completion, values[0]..values[endIndex] are sorted.
	{
		boolean finished = false;
		boolean moreToSearch = true;
		int current = endIndex;
		
		while (moreToSearch && !finished)
		{
			cntSwaps[sortIdentifier]++;
			if (values[current] < values[current - 1])
			{
				swap(current, current - 1);
				current--;
				moreToSearch = (current != startIndex);
			} 
			else
				finished = true;
		}
	}
	public static long startClock()
	{
		return System.nanoTime();
	}
	public static long stopClock()
	{
		return System.nanoTime();
	}
	static public void printValues()						// Prints all the values integers.
	{
		int value;
		DecimalFormat fmt = new DecimalFormat("00");
		switch (sortIdentifier)
		{
			case 0:	System.out.println("The Selection Sort values are:  ");		break;
			case 1:	System.out.println("The Bubble Sort values are:  ");		break;
			case 2:	System.out.println("The Short Bubble Sort values are:  ");	break;
			case 3:	System.out.println("The Insertion Sort values are:  ");		break;
		}
		
		for (int index = 0; index < SIZE; index++)
		{
			value = values[index];
			if (((index + 1) % SIZE) == 0)		System.out.println(fmt.format(value));
			else								System.out.print(fmt.format(value) + " ");
		}
		System.out.println();
	}
	public static void printData()	//	Output cntComparisons, cntSwaps, Efficiency, ImprovedEfficiency, and CPU Time
	{
		/*	Efficiency = cntComparisons/SIZE
		 * 	ImprovedEfficiency = (cntComparisons + cntSwaps)/SIZE
		 *  CPU time in seconds to two significant digits, i.e. 5.23s (use DecimalFormat)
		 */
		DecimalFormat fmt = new DecimalFormat("0.00");
		
		printValues();		
		switch (sortIdentifier)
		{
			case 0:	System.out.print("Selection Sort:  ");		break;
			case 1:	System.out.print("Bubble Sort:  ");			break;
			case 2:	System.out.print("Short Bubble Sort:  ");	break;
			case 3:	System.out.print("Insertion Sort:  ");	break;
		}
		
		System.out.println("Comparisons = " 		+ cntComparisons[sortIdentifier]);
		System.out.println("Swaps = " 				+ cntSwaps[sortIdentifier]);
		System.out.println("Efficiency = "			+ (cntComparisons[sortIdentifier]/SIZE));
		System.out.println("Improved Efficiency = "	+ ((cntComparisons[sortIdentifier] + cntSwaps[sortIdentifier]) /SIZE));
		System.out.println("CPU Time = " + 
							fmt.format((double)(stopTime[sortIdentifier]-startTime[sortIdentifier])*(Math.pow(10, -9))) + "s");
							
		System.out.println();
	}
	public static void main(String[] args)
	{
		BufferedReader stdin = new BufferedReader(new InputStreamReader(System.in));
		for (sortIdentifier = 0; sortIdentifier < 4; sortIdentifier++)	// make call to sorting method here
		{
			initRndValues();		//	Creates a random array
			initAscValues();		//	Creates an array with ascending values
			initDescValues();		//	Creates an array with descending values
			
			switch (sortIdentifier)
			{
				case 0:	//	Selection Sort
				{
					System.out.println("Selection Sort Values are sorted: " + isSorted());
					printValues();
					selectionSort();
					System.out.println("Selection Sort Values are sorted: " + isSorted());
					printData();
					break;
				}
				case 1:	//	Bubble Sort
				{
					System.out.println("Bubble Sort Values are sorted: " + isSorted());
					printValues();
					bubbleSort();
					System.out.println("Bubble Sort Values are sorted: " + isSorted());
					printData();
					break;
				}
				case 2:	//	Short Bubble Sort
				{
					System.out.println("Short Bubble Sort Values are sorted: " + isSorted());
					printValues();
					shortBubble();
					System.out.println("Short Bubble Sort Values are sorted: " + isSorted());
					printData();
					break;
				}
				case 3:	//	Insertion Sort
				{
					System.out.println("Insertion Sort Values are sorted: " + isSorted());
					printValues();
					insertionSort();
					System.out.println("Insertion Sort Values are sorted: " + isSorted());
					printData();
					break;
				}
			}
			try
			{
				stdin.readLine();
			} catch (IOException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}		
	}
}