package com.school.snake;

public class GameHandler extends Thread
{	
	FrameworkHandler	framework;
	
	boolean				exitApp		=	false,
						gameOver	=	false,
						gameRunning	=	false;
	
	public GameHandler(FrameworkHandler framework)
	{
		this.framework	=	framework;
	}
	
	public void run()
	{
		while (!exitApp)
		{
			if (gameRunning)
			{
				try
				{
					sleep(100);
				}
				catch (InterruptedException e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			if (gameOver)
			{
				gameRunning	=	false;
				endGame();
			}
		}
	}
	
	public void terminate()
	{
		endGame();
		interrupt();
	}
	
	public void startGame()
	{
		gameRunning	=	true;
		gameOver	=	false;
		exitApp		=	false;
	}
	
	public void endGame()
	{
		exitApp		=	false;
		gameOver	=	false;
		gameRunning	=	false;
	}
}